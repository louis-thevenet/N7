// Time-stamp: <02 mai 2013 10:14 queinnec@enseeiht.fr>

public interface IHMVU {
    public void ajouterTrain(Position posInit);
    public void enleverTrain();
    public void changerEtat(Position pos);
}
